/*
  可选静态配置。
  推荐直接在网页里点击“选择素材文件夹”，无需修改这里。

  歌名会从 audio 文件名读取：
  assets/audio/01 歌名.wav  →  画面显示“歌名”

  图片可以少于歌曲，多首歌可以填写同一个 image。
  页面内按 G 可打开“曲目设置”，重新指定图片并选择试听起点。

  window.ALBUM_CONFIG = {
    albumTitle: "YOUR ALBUM",
    artist: "YOUR NAME",
    tracks: [
      {
        audio: "assets/audio/01 Song One.wav",
        image: "assets/images/01.jpg",
        startAt: 0,
        objectPosition: "50% 50%"
      },
      {
        audio: "assets/audio/02 Song Two.wav",
        image: "assets/images/01.jpg"
      }
    ]
  };
*/

window.ALBUM_CONFIG = {
  albumTitle: "UNNAMED ALBUM",
  artist: "YOUR NAME",
  tracks: []
};
